@extends('backend.layout.app')
@section('content')
    @include('backend.components.auth.send-otp-form')
@endsection


