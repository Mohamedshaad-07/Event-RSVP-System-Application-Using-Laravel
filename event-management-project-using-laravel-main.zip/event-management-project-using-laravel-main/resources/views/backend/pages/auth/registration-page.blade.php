@extends('backend.layout.app')
@section('content')
    @include('backend.components.auth.registration-form')
@endsection
