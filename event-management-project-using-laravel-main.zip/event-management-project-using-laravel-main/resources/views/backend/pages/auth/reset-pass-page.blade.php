@extends('backend.layout.app')
@section('content')
    @include('backend.components.auth.reset-pass-form')
@endsection

