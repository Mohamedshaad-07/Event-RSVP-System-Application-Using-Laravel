@extends('backend.layout.sidenav-layout')
@section('content')
    @include('backend.components.report.report-list')
@endsection
