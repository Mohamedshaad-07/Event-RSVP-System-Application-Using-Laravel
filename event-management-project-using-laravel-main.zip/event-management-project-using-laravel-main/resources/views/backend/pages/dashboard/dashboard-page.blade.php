@extends('backend.layout.sidenav-layout')
@section('content')
    @include('backend.components.dashboard.summary')
@endsection

