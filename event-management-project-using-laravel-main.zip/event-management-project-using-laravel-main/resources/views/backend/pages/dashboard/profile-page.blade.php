@extends('backend.layout.sidenav-layout')
@section('content')
    @include('backend.components.dashboard.profile-form')
@endsection

