<!-- Begin AlertBar
================================================== -->
<div class="alertbar">
	<div class="container text-center">
		<!-- Trigger the modal with a button -->
		<img src="assets/img/logo.png" alt=""> &nbsp; Never miss this <b>event</b> Join Hurry Up. <a href="#" class="btn subscribe" data-toggle="modal" data-target="#myModal">Join Now</a>
	</div>
</div>
<!-- End AlertBar
================================================== -->