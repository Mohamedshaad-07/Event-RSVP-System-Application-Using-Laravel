<!-- Begin Site Title
================================================== -->
<div class="container">
	<div class="mainheading">
		<h1 class="sitetitle">Mediumish</h1>
		<p class="lead">
			All Events are fantastic choice for all. Join Now.
		</p>
	</div>
<!-- End Site Title
================================================== -->