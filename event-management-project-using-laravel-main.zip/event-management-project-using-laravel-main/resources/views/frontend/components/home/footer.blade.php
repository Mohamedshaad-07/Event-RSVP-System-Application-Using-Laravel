<!-- Begin Footer
================================================== -->
<div class="footer">
    <p class="pull-left">
            Copyright &copy; {{ date('Y') }} Event Managment
    </p>
    <p class="pull-right">
            Developed by <a target="_blank" href="https://www.coderstream.com">coderstream.com</a>
    </p>
    <div class="clearfix">
    </div>
</div>
<!-- End Footer
================================================== -->