@extends('frontend.layout.app')
@section('content')
    @include('frontend.components.home.site-title')
    @include('frontend.components.home.feature')
    @include('frontend.components.home.recent')
    @include('frontend.components.home.footer')
@endsection

